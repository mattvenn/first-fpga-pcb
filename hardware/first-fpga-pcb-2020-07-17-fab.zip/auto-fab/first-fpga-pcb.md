# PCB layout for first fpga

\ ![overview](auto-fab/first-fpga-pcb-overview.png)

# Configuration

* 100.1 x 68.1mm
* 1.6 mm FR4, white silkscreen, green/any mask
* 2 layers, 35um copper
* generated on 2020-07-17 15:18:01.789041, git version a7176f1
