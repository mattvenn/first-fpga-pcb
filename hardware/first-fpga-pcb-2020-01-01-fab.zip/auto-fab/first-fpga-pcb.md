# PCB layout for first fpga

\ ![overview](auto-fab/first-fpga-pcb-overview.png)

# Configuration

* 100.1 x 70.1mm
* 1.6 mm FR4, white silkscreen, green/any mask
* 2 layers, 35um copper
* generated on 2020-01-01 11:42:12.200488, git version d9c7cdf
